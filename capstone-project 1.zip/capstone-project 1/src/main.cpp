#include <iostream>
#include "FileExplorer.h"

int main() {
    FileExplorer fe;
    int choice;
    std::string input1, input2;
    int perm;

    while (true) {
        std::cout << "\nCurrent Directory: " << fe.getCurrentPath() << "\n";
        std::cout << "1. List Files\n2. Change Directory\n3. Create File\n4. Delete File\n";
        std::cout << "5. Copy File\n6. Move File\n7. Search File\n8. Set Permissions\n9. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

        switch(choice) {
            case 1:
                fe.listFiles();
                break;
            case 2:
                std::cout << "Enter directory name: ";
                std::cin >> input1;
                fe.changeDirectory(input1);
                break;
            case 3:
                std::cout << "Enter file name: ";
                std::cin >> input1;
                fe.createFile(input1);
                break;
            case 4:
                std::cout << "Enter file name: ";
                std::cin >> input1;
                fe.deleteFile(input1);
                break;
            case 5:
                std::cout << "Enter source and destination file names: ";
                std::cin >> input1 >> input2;
                fe.copyFile(input1, input2);
                break;
            case 6:
                std::cout << "Enter source and destination file names: ";
                std::cin >> input1 >> input2;
                fe.moveFile(input1, input2);
                break;
            case 7:
                std::cout << "Enter file name to search: ";
                std::cin >> input1;
                fe.searchFile(input1);
                break;
            case 8:
                std::cout << "Enter file name and permission (e.g., 0644): ";
                std::cin >> input1 >> std::oct >> perm;
                fe.setPermissions(input1, perm);
                break;
            case 9:
                return 0;
            default:
                std::cout << "Invalid choice!\n";
        }
    }
}
