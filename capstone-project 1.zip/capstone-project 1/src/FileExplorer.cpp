#include "FileExplorer.h"
#include <iostream>
#include <filesystem>
#include <fstream>
#include <unistd.h>
#include <sys/stat.h>
#include <vector>

namespace fs = std::filesystem;

FileExplorer::FileExplorer() {
    currentPath = fs::current_path();
}

std::string FileExplorer::getCurrentPath() {
    return currentPath;
}

void FileExplorer::listFiles() {
    std::cout << "Files in " << currentPath << ":\n";
    for (auto &p : fs::directory_iterator(currentPath)) {
        std::cout << p.path().filename().string() << "\n";
    }
}

void FileExplorer::changeDirectory(const std::string &path) {
    std::string newPath = currentPath + "/" + path;
    if (fs::exists(newPath) && fs::is_directory(newPath)) {
        currentPath = newPath;
        std::cout << "Changed directory to: " << currentPath << "\n";
    } else {
        std::cout << "Directory does not exist!\n";
    }
}

void FileExplorer::createFile(const std::string &filename) {
    std::ofstream file(currentPath + "/" + filename);
    file.close();
    std::cout << "File created: " << filename << "\n";
}

void FileExplorer::deleteFile(const std::string &filename) {
    std::string fullPath = currentPath + "/" + filename;
    if (fs::exists(fullPath)) {
        fs::remove(fullPath);
        std::cout << "Deleted: " << filename << "\n";
    } else {
        std::cout << "File does not exist!\n";
    }
}

void FileExplorer::copyFile(const std::string &source, const std::string &destination) {
    std::string srcPath = currentPath + "/" + source;
    std::string destPath = currentPath + "/" + destination;
    if (fs::exists(srcPath)) {
        fs::copy(srcPath, destPath, fs::copy_options::overwrite_existing);
        std::cout << "Copied " << source << " to " << destination << "\n";
    } else {
        std::cout << "Source file does not exist!\n";
    }
}

void FileExplorer::moveFile(const std::string &source, const std::string &destination) {
    std::string srcPath = currentPath + "/" + source;
    std::string destPath = currentPath + "/" + destination;
    if (fs::exists(srcPath)) {
        fs::rename(srcPath, destPath);
        std::cout << "Moved " << source << " to " << destination << "\n";
    } else {
        std::cout << "Source file does not exist!\n";
    }
}

void FileExplorer::searchFile(const std::string &filename) {
    bool found = false;
    for (auto &p : fs::recursive_directory_iterator(currentPath)) {
        if (p.path().filename() == filename) {
            std::cout << "Found: " << p.path() << "\n";
            found = true;
        }
    }
    if (!found) std::cout << "File not found!\n";
}

void FileExplorer::setPermissions(const std::string &filename, int permissions) {
    std::string fullPath = currentPath + "/" + filename;
    if (fs::exists(fullPath)) {
        chmod(fullPath.c_str(), permissions);
        std::cout << "Permissions updated for " << filename << "\n";
    } else {
        std::cout << "File does not exist!\n";
    }
}
