#ifndef FILEEXPLORER_H
#define FILEEXPLORER_H

#include <string>
#include <vector>

class FileExplorer {
private:
    std::string currentPath;

public:
    FileExplorer();
    void listFiles();
    void changeDirectory(const std::string &path);
    void createFile(const std::string &filename);
    void deleteFile(const std::string &filename);
    void copyFile(const std::string &source, const std::string &destination);
    void moveFile(const std::string &source, const std::string &destination);
    void searchFile(const std::string &filename);
    void setPermissions(const std::string &filename, int permissions);
    std::string getCurrentPath();
};

#endif
